/// <reference types="cypress" />

describe("E2E - Wgrywanie pliku", () => {
    it("Wgrywanie pliku w input Contact Us", () => {
        cy.visit("/index.php?controller=contact")
        cy.get("#fileUpload").attachFile("../fixtures/website.jpg")
        cy.get("span.filename").should("contain", "website.jpg")
     
    })
})