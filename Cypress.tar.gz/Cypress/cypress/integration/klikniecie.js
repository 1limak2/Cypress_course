/// <reference types="cypress" />

describe("E2E - Akcje klikniecia", () => {
    it("klikniecie na element", () => {
        cy.visit("/")
        cy.contains('[title="Contact US"]', 'Contact us').click();
        cy.get('[title="Return to Home"]').click();
    })
})