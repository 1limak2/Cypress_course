/// <reference types="cypress" />

describe("E2E - Akcja wpisywania", () => {
    it("Wpisywanie wartosci w pole", () => {
        cy.visit("/");
        cy.get("#search_query_top").type("Dress {enter}", {delay: 500})
 
    })

    // it("Czysczenie wartosci z pola input", () => {

    // })
})