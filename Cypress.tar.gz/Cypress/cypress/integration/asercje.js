/// <reference types="cypress" />

describe("E2E - Asercje", () => {
    it("Asercje expect oraz should", () => {
        cy.visit("/")

        //Weryfikacja tekstu
        cy.get('a[title="Contact us"]').should("contain", "Contact us");
        cy.get('a[title="Contact us"]').then(zakladka => {
            expect(zakladka).to.contain("Contact us")
        })
        //Sprawdzenie czy nie zawieru tekstu
        cy.get('a[title="Contact us"]').should("not.contain", "XXXXXYYY")
        cy.get('a[title="Contact us"]').then(zakladki => {
            expect(zakladki).not.to.contain("XXXXXYYY")
        
        //Weryfikacja czy znacznik posiada klase
        cy.get("#search_query_top").should("have.class", "form-control")
        cy.get("#search_query_top").then(wyszukiwarka => {
            expect(wyszukiwarka).to.have.class("form-control")
        })

        //Weryfikacja wartoci CSS danego elementu
        cy.get("#search_query_top").should("have.css", "line-height", "45px")
        cy.get("#search_query_top").then(wyszukiwarka => {
            expect(wyszukiwarka).to.have.css("line-height", "45px")
        })

    })
})

})