/// <reference types="cypress" />

import SelectPage from "../support/page-object/selectPage";

describe("E2E - Akcje wybrania opcji selekt", () => {
    it("Wybieranie opcji", () => {
        cy.visit("/index.php?id_category=3&controller=category#/")

        //Wybieranie opcji za pomoca metody "select" po nazwie
        cy.get("#selectProductSort").select("In stock")

        //Po "value" /wartosci/
        cy.get("#selectProductSort").select("price:asc")

        //Po indeksach
        cy.get("#selectProductSort").select(7)

    })

    it.only("Wybieranie wszystkich opcji", () => {
        cy.visit("/index.php?id_category=3&controller=category#/")
        SelectPage.select_all_option();

        // cy.get("#selectProductSort").then(select => {
        //     cy.wrap(select).find("option").each(opcja => {
        //         cy.wrap(select).select(opcja.text())
        //     })
        // })
    })
})