/// <reference types="cypress" />

describe("E2E - Lesson", () => {
    it("Lokalizatorach", () => {
        cy.visit("/")

        //Po znaczniku
        cy.get("a");

        //Identyfikator
        cy.get("#search_query_top")

        //Po klasie
        cy.get(".form-control")

        //Po atrybutach
        cy.get('[name="search_query"]')
        cy.get('[placeholder="Search"]')

        //Dokladniejszy atrybut wraz z podaniem znacznika
        cy.get('[placeholder="Search"]')

        //Pobieranie elemenow po kilku atrybutach
        cy.get('[src="http://automationpractice.com/modules/themeconfigurator/img/banner-img7.jpg"][width="381"]')

    })
    //Po tekscie
    it.only("Lokalizatory czesc 2", () => {
        cy.visit("/")
        cy.contains('[title="Contact us"]', 'Contact us')
        
        cy.get("li").parents("#home-page-tabs").find("li").eq(1)
    })


})