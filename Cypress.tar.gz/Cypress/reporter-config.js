{
  "reporterEnabled"; "mocha-junit-reporter",
   "mochaJunitReporterReporterOptions"; {
     "mochaFile"; "cypress/results/results-[hash].xml"
  }
}
